"""SMC Core modules"""
